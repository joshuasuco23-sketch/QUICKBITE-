import React from "react";

export default function RatingStars({ rating, onRate }) {
  return (
    <div style={{ display: "flex", gap: "5px", cursor: "pointer" }}>
      {[1, 2, 3, 4, 5].map((star) => (
        <span
          key={star}
          onClick={() => onRate(star)}
          style={{
            fontSize: "24px",
            color: star <= rating ? "#FFD700" : "#ccc",
            transition: "0.2s"
          }}
        >
          ★
        </span>
      ))}
    </div>
  );
}
