import React, { useState } from "react";
import RatingStars from "./RatingStars";

export default function Reviews() {
  const [rating, setRating] = useState(0);
  const [reviewText, setReviewText] = useState("");
  const [reviews, setReviews] = useState([]);

  const submitReview = () => {
    if (!rating || reviewText.trim() === "") return;

    const newReview = {
      id: Date.now(),
      rating,
      text: reviewText
    };

    setReviews([newReview, ...reviews]);
    setRating(0);
    setReviewText("");
  };

  return (
    <div style={{ maxWidth: "600px", margin: "auto", padding: "20px" }}>
      <h2 style={{ marginBottom: "10px" }}>Reviews & Ratings</h2>

      <RatingStars rating={rating} onRate={setRating} />

      <textarea
        value={reviewText}
        onChange={(e) => setReviewText(e.target.value)}
        placeholder="Write your review..."
        style={{
          width: "100%",
          height: "90px",
          marginTop: "15px",
          padding: "10px",
          borderRadius: "8px",
          border: "1px solid #ccc"
        }}
      />

      <button
        onClick={submitReview}
        style={{
          marginTop: "10px",
          padding: "10px 18px",
          border: "none",
          background: "#2EA44F",
          color: "white",
          borderRadius: "5px",
          cursor: "pointer"
        }}
      >
        Submit Review
      </button>

      <hr style={{ margin: "20px 0" }} />

      <h3>Customer Reviews</h3>
      {reviews.length === 0 && <p>No reviews yet. Be the first!</p>}

      {reviews.map((r) => (
        <div
          key={r.id}
          style={{
            background: "#f8f8f8",
            padding: "12px",
            marginTop: "10px",
            borderRadius: "10px"
          }}
        >
          <RatingStars rating={r.rating} onRate={() => {}} />
          <p style={{ marginTop: "5px" }}>{r.text}</p>
        </div>
      ))}
    </div>
  );
}
