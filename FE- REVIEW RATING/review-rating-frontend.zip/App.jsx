import React from "react";
import Reviews from "./Reviews";

export default function App() {
  return (
    <div>
      <Reviews />
    </div>
  );
}
