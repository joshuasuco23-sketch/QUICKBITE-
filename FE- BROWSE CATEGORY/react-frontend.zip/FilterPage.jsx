import React, { useState } from "react";

export default function FilterPage() {
  const categories = [
    { id: "snack", label: "Snack" },
    { id: "meal", label: "Meal" },
    { id: "vegan", label: "Vegan" },
    { id: "dessert", label: "Dessert" },
    { id: "drinks", label: "Drinks" }
  ];

  const items = {
    snack: ["Hotdog with Bun","Donut","Hotcake","Presto","Siomai","Baked Pan"],
    meal: ["Tapsilog","Tocilog","Fried Chicken","Tinola","Bangsilog","Fried Fish"],
    vegan: ["Bean Burger","Lasagna","Vegetarian Ulam","Broccoli","Mushroom","Pinakbet","Salad"]
  };

  const [activeCategory, setActiveCategory] = useState("snack");
  const [sort, setSort] = useState(4);

  return (
    <div className="min-h-screen bg-gray-100 p-4 font-sans">
      <div className="bg-blue-600 rounded-b-2xl p-6 text-white text-xl font-semibold">
        Filter
      </div>

      <div className="mt-6">
        <h2 className="text-lg font-semibold mb-2">Categories</h2>
        <div className="flex gap-4">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveCategory(c.id)}
              className={\`px-4 py-2 rounded-full border transition-all \${activeCategory === c.id ? "bg-green-500 text-white":"bg-yellow-300 text-black"}\`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6">
        <h2 className="text-lg font-semibold mb-2">Sort by</h2>
        <div className="flex gap-1 text-yellow-500 text-2xl">
          {[1,2,3,4,5].map((n)=>(
            <span key={n} onClick={()=>setSort(n)} className={\`cursor-pointer \${sort>=n?"opacity-100":"opacity-40"}\`}>
              ★
            </span>
          ))}
        </div>
      </div>

      <div className="mt-6">
        <h2 className="text-lg font-semibold mb-2">Categories</h2>
        <div className="flex flex-wrap gap-2">
          {items[activeCategory].map((item)=>(
            <span key={item} className="px-4 py-2 bg-gray-200 rounded-full border text-sm">
              {item}
            </span>
          ))}
        </div>
      </div>

      <div className="mt-8">
        <button className="w-full bg-green-600 text-white py-3 rounded-xl text-lg font-semibold shadow">
          Apply
        </button>
      </div>
    </div>
  );
}
