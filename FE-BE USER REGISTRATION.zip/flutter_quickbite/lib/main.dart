import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(QuickBiteApp());
}

class QuickBiteApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QuickBite',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: QuickBiteHome(),
    );
  }
}

class QuickBiteHome extends StatefulWidget {
  @override
  _QuickBiteHomeState createState() => _QuickBiteHomeState();
}

class _QuickBiteHomeState extends State<QuickBiteHome> {
  bool isLogin = true;
  final _loginEmail = TextEditingController();
  final _loginPass = TextEditingController();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();

  final apiBase = 'http://10.0.2.2:4000'; // emulator localhost mapping; change for device

  void showToast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> submitLogin() async {
    final resp = await http.post(Uri.parse('$apiBase/api/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'identifier': _loginEmail.text, 'password': _loginPass.text}));
    if (resp.statusCode == 200) {
      showToast('Login successful');
    } else {
      showToast('Login failed: ' + resp.body);
    }
  }

  Future<void> submitSignup() async {
    final resp = await http.post(Uri.parse('$apiBase/api/auth/signup'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'name': _name.text, 'email': _email.text, 'password': _password.text}));
    if (resp.statusCode == 200) {
      showToast('Signup successful');
      setState(() => isLogin = true);
    } else {
      showToast('Signup failed: ' + resp.body);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(isLogin ? 'Log In' : 'Sign Up')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isLogin ? buildLogin() : buildSignup(),
      ),
    );
  }

  Widget buildLogin() {
    return Column(
      children: [
        TextField(controller: _loginEmail, decoration: InputDecoration(labelText: 'Email or mobile')),
        TextField(controller: _loginPass, decoration: InputDecoration(labelText: 'Password'), obscureText: true),
        SizedBox(height: 12),
        ElevatedButton(onPressed: submitLogin, child: Text('Log In')),
        TextButton(onPressed: () => setState(()=>isLogin=false), child: Text('Create account')),
      ],
    );
  }

  Widget buildSignup() {
    return Column(
      children: [
        TextField(controller: _name, decoration: InputDecoration(labelText: 'Full name')),
        TextField(controller: _email, decoration: InputDecoration(labelText: 'Email')),
        TextField(controller: _password, decoration: InputDecoration(labelText: 'Password'), obscureText: true),
        SizedBox(height: 12),
        ElevatedButton(onPressed: submitSignup, child: Text('Sign Up')),
        TextButton(onPressed: () => setState(()=>isLogin=true), child: Text('Back to login')),
      ],
    );
  }
}
