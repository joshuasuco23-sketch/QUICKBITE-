import React, { useState } from "react";

export default function App() {
  const [view, setView] = useState("login");
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState(null);

  const [loginEmail, setLoginEmail] = useState("");
  const [loginPass, setLoginPass] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mobile, setMobile] = useState("");
  const [dob, setDob] = useState("");
  const baseURL = import.meta.env.VITE_API_BASE || "http://localhost:4000";

  function validateEmail(e) { return /^\S+@\S+\.\S+$/.test(e); }
  function showToast(msg, time = 3000) { setToast(msg); setTimeout(()=>setToast(null), time); }

  async function handleLogin(e) {
    e && e.preventDefault();
    if (!loginEmail || !loginPass) return showToast("Please enter email and password");
    setLoading(true);
    try {
      const resp = await fetch(`${baseURL}/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier: loginEmail, password: loginPass }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data?.message || "Login failed");
      showToast("Logged in — token saved in localStorage");
      localStorage.setItem("qb_token", data.token);
    } catch (err) {
      showToast(err.message || "Error during login");
    } finally { setLoading(false); }
  }

  async function handleSignup(e) {
    e && e.preventDefault();
    if (!name || !email || !password) return showToast("Please fill required fields");
    if (!validateEmail(email)) return showToast("Please enter a valid email");
    setLoading(true);
    try {
      const resp = await fetch(`${baseURL}/api/auth/signup`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password, mobile, dob }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data?.message || "Signup failed");
      showToast("Account created — please verify your email");
      setView("login");
    } catch (err) {
      showToast(err.message || "Error during signup");
    } finally { setLoading(false); }
  }

  return (
    <div className="qb-root">
      <div className="qb-frame" role="application" aria-label="QuickBite app">
        <header className="qb-header">
          <div style={{width:36,height:36,display:'grid',placeItems:'center',background:'rgba(255,255,255,0.08)',borderRadius:10}}>⟵</div>
          <h1>{view === 'login' ? 'Log In' : 'Create Account'}</h1>
        </header>

        <div className="qb-body">
          <div className="qb-card">
            {view === 'login' ? (
              <form onSubmit={handleLogin} aria-label="Login form">
                <h2 style={{margin:'0 0 8px 0'}}>Welcome back</h2>
                <div className="muted">Sign in to continue to QuickBite</div>

                <label htmlFor="loginEmail">Email or mobile</label>
                <input id="loginEmail" value={loginEmail} onChange={e=>setLoginEmail(e.target.value)} placeholder="you@example.com" />

                <label htmlFor="loginPass">Password</label>
                <input id="loginPass" value={loginPass} onChange={e=>setLoginPass(e.target.value)} type="password" />

                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:8}}>
                  <div className="muted">&nbsp;</div>
                  <div className="link" onClick={()=>showToast('Password reset flow (backend required)')}>Forgot password?</div>
                </div>

                <button className="btn" type="submit" disabled={loading}>{loading ? 'Please wait...' : 'Log In'}</button>

                <div className="or" style={{marginTop:16,display:'flex',alignItems:'center',gap:10}}>
                  <div style={{flex:1,height:1,background:'#eef2ff'}} />
                  <div style={{color:'#9aa4c0',fontSize:13}}>or sign up with</div>
                  <div style={{flex:1,height:1,background:'#eef2ff'}} />
                </div>

                <div className="socials">
                  <div className="soc">G</div>
                  <div className="soc">f</div>
                  <div className="soc"></div>
                </div>

                <div style={{textAlign:'center',marginTop:12,fontSize:13}}>
                  Don't have an account? <span className="link" onClick={()=>setView('signup')}>Sign up</span>
                </div>
              </form>
            ) : (
              <form onSubmit={handleSignup} aria-label="Signup form">
                <h2 style={{margin:'0 0 8px 0'}}>Create your account</h2>
                <div className="muted">Start ordering from nearby restaurants</div>

                <label>Full name</label>
                <input value={name} onChange={e=>setName(e.target.value)} placeholder="Jane Doe" />

                <label>Email</label>
                <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" />

                <label>Password</label>
                <input type="password" value={password} onChange={e=>setPassword(e.target.value)} />

                <div className="row">
                  <div style={{flex:1}}>
                    <label>Mobile</label>
                    <input value={mobile} onChange={e=>setMobile(e.target.value)} placeholder="+63 912 345 6789" />
                  </div>
                  <div style={{width:120}}>
                    <label>DOB</label>
                    <input type="date" value={dob} onChange={e=>setDob(e.target.value)} />
                  </div>
                </div>

                <div style={{fontSize:12,color:'#8894b0',marginTop:10}}>By continuing you agree to QuickBite's Terms & Privacy</div>

                <button className="btn" type="submit" disabled={loading}>{loading ? 'Please wait...' : 'Sign Up'}</button>

                <div style={{textAlign:'center',marginTop:12,fontSize:13}}>
                  Already have an account? <span className="link" onClick={()=>setView('login')}>Log in</span>
                </div>
              </form>
            )}
          </div>
        </div>

        <div className="bottom">QuickBite — prototype</div>
      </div>

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
