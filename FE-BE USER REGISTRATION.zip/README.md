QuickBite Fullstack Demo

Folders:
- react-quickbite : React (Vite) frontend. Run: npm install && npm run dev
- mock-backend : Node + Express mock backend. Run: npm install && npm start
- flutter_quickbite : Flutter minimal app. Run with `flutter run`. Note: change API base if using real device.

Instructions:
1. Start mock backend:
   cd mock-backend
   npm install
   node index.js

2. Start React frontend:
   cd react-quickbite
   npm install
   npm run dev
   Open browser at the address printed by Vite (usually http://localhost:5173)

3. (Optional) Run Flutter app:
   cd flutter_quickbite
   flutter pub get
   flutter run

The React app expects the backend at http://localhost:4000 by default (VITE_API_BASE can change this).
