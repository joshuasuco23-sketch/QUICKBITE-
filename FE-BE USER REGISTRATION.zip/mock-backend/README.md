# Mock Backend (QuickBite)

## Install
```
npm install
```

## Run
```
node index.js
```

This server provides:
- POST /api/auth/signup
- POST /api/auth/login
- GET /api/profile (requires `Authorization: Bearer <token>`)
Note: Uses in-memory store. Not for production.
