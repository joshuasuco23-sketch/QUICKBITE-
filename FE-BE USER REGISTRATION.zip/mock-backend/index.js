const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'devsecret';

// Simple in-memory 'users' store (DO NOT USE IN PRODUCTION)
const users = [];

app.post('/api/auth/signup', (req, res) => {
  const { name, email, password, mobile, dob } = req.body;
  if(!email || !password || !name) return res.status(400).json({ message: 'Missing required fields' });
  if(users.find(u => u.email === email)) return res.status(409).json({ message: 'Email already exists' });
  const user = { id: users.length+1, name, email, password, mobile, dob };
  users.push(user);
  res.json({ message: 'User created', userId: user.id });
});

app.post('/api/auth/login', (req, res) => {
  const { identifier, password } = req.body;
  if(!identifier || !password) return res.status(400).json({ message: 'Missing credentials' });
  // allow login by email or mobile
  const user = users.find(u => (u.email === identifier || u.mobile === identifier) && u.password === password);
  if(!user) return res.status(401).json({ message: 'Invalid credentials' });
  const token = jwt.sign({ sub: user.id, name: user.name }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

app.get('/api/profile', (req, res) => {
  const auth = req.headers.authorization;
  if(!auth) return res.status(401).json({ message: 'No token' });
  const token = auth.replace('Bearer ','');
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = users.find(u => u.id === payload.sub);
    if(!user) return res.status(404).json({ message: 'User not found' });
    res.json({ id: user.id, name: user.name, email: user.email, mobile: user.mobile });
  } catch(e) {
    return res.status(401).json({ message: 'Invalid token' });
  }
});

app.listen(PORT, ()=> console.log(`Mock backend running on http://localhost:${PORT}`));
