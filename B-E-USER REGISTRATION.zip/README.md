# B-E LOG IN SYSTEM (Node + Express)

Minimal backend for the registration/login demo using sqlite3.

## Quick start
1. `cd` into this folder.
2. `npm install`
3. `npm start`
4. Server listens on port 4000 by default.

The database file `users.db` will be created automatically next to `index.js`.
